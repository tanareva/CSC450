"""
This file will generate the notifications and pass them to an email and send that email

Matt Jarrett
"""
#import User

#def __init__(self, user: User):
    #self.user = user


def hello():
    return "Hello from Component Notifications"
