
class accountInfo:

    def __init__(self, accountPreferences, notificationPreferences):
        self.accountPreferences = accountPreferences
        self.notificationPreferences = notificationPreferences

